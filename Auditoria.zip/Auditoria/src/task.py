# mi_manejador_tareas/src/task.py

class Task:
    def __init__(self, task_id, description, due_date, priority, status="Pendiente"):
        self.id = task_id
        self.description = description
        self.due_date = due_date
        self.priority = priority
        self.status = status

    def __repr__(self):
        return (f"Task(ID={self.id}, Desc='{self.description}', Due='{self.due_date}', "
                f"Prio='{self.priority}', Status='{self.status}')")

    def to_list(self):
        """Convierte la tarea en una lista para facilitar la escritura en Excel."""
        return [self.id, self.description, self.due_date, self.priority, self.status]

    @staticmethod
    def from_list(data):
        """Crea un objeto Task desde una lista de datos (ej. fila de Excel)."""
        if len(data) != 5:
            raise ValueError("La lista de datos debe contener 5 elementos para crear una Tarea.")
        return Task(data[0], data[1], data[2], data[3], data[4])