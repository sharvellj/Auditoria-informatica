# mi_manejador_tareas/src/task_manager.py

import openpyxl
import os
from src.task import Task # ¡Importante! Ahora se importa desde 'src.task'

class TaskManager:
    def __init__(self, excel_file="tasks.xlsx"):
        self.excel_file = excel_file
        self.workbook = None
        self.sheet = None
        self._load_workbook()

    def _load_workbook(self):
        """Carga el libro de trabajo o crea uno nuevo si no existe."""
        if os.path.exists(self.excel_file):
            self.workbook = openpyxl.load_workbook(self.excel_file)
            self.sheet = self.workbook.active
            if self.sheet.max_row == 1 and self.sheet.cell(row=1, column=1).value is None:
                self._initialize_sheet()
            else:
                headers = [self.sheet.cell(row=1, column=col).value for col in range(1, self.sheet.max_column + 1)]
                expected_headers = ["ID", "Descripcion", "Fecha Vencimiento", "Prioridad", "Estado"]
                if not all(h in headers for h in expected_headers):
                    self._initialize_sheet()
        else:
            self.workbook = openpyxl.Workbook()
            self.sheet = self.workbook.active
            self._initialize_sheet()
        self.workbook.save(self.excel_file)

    def _initialize_sheet(self):
        """Inicializa la hoja con los encabezados si es una hoja nueva o vacía."""
        self.sheet.delete_rows(1, self.sheet.max_row)
        self.sheet.title = "Tareas"
        self.sheet['A1'] = "ID"
        self.sheet['B1'] = "Descripcion"
        self.sheet['C1'] = "Fecha Vencimiento"
        self.sheet['D1'] = "Prioridad"
        self.sheet['E1'] = "Estado"
        self.workbook.save(self.excel_file)

    def _get_next_id(self):
        """Genera el próximo ID disponible."""
        max_id = 0
        for row in range(2, self.sheet.max_row + 1):
            cell_value = self.sheet.cell(row=row, column=1).value
            if isinstance(cell_value, (int, float)):
                max_id = max(max_id, int(cell_value))
        return max_id + 1

    def add_task(self, description, due_date, priority):
        """Agrega una nueva tarea al Excel."""
        task_id = self._get_next_id()
        new_task = Task(task_id, description, due_date, priority)
        self.sheet.append(new_task.to_list())
        self.workbook.save(self.excel_file)
        return new_task

    def get_all_tasks(self):
        """Obtiene todas las tareas del Excel."""
        tasks = []
        for row_idx in range(2, self.sheet.max_row + 1):
            row_data = [self.sheet.cell(row=row_idx, column=col_idx).value for col_idx in range(1, 6)]
            if any(row_data):
                try:
                    task = Task.from_list(row_data)
                    tasks.append(task)
                except ValueError as e:
                    print(f"Error al cargar la tarea de la fila {row_idx}: {e} - Datos: {row_data}")
        return tasks

    def update_task(self, task_id, description=None, due_date=None, priority=None, status=None):
        """Actualiza una tarea existente por su ID."""
        for row_idx in range(2, self.sheet.max_row + 1):
            if self.sheet.cell(row=row_idx, column=1).value == task_id:
                if description is not None:
                    self.sheet.cell(row=row_idx, column=2).value = description
                if due_date is not None:
                    self.sheet.cell(row=row_idx, column=3).value = due_date
                if priority is not None:
                    self.sheet.cell(row=row_idx, column=4).value = priority
                if status is not None:
                    self.sheet.cell(row=row_idx, column=5).value = status
                self.workbook.save(self.excel_file)
                return True
        return False

    def delete_task(self, task_id):
        """Elimina una tarea por su ID."""
        for row_idx in range(2, self.sheet.max_row + 1):
            if self.sheet.cell(row=row_idx, column=1).value == task_id:
                self.sheet.delete_rows(row_idx, 1)
                self.workbook.save(self.excel_file)
                return True
        return False

    def close(self):
        """Cierra el libro de trabajo."""
        if self.workbook:
            self.workbook.close()