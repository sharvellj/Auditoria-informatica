# mi_manejador_tareas/main.py

import sys
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
                             QHeaderView, QMessageBox, QComboBox, QLabel, QDateEdit)
from PyQt6.QtCore import Qt, QDate
from src.task_manager import TaskManager
from src.task import Task
import os

class TaskApp(QWidget):
    def __init__(self):
        super().__init__()
        self.task_manager = TaskManager()
        self.setWindowTitle("Manejador de Tareas")
        self.setGeometry(100, 100, 800, 600)
        self.init_ui()
        self.load_tasks_to_table()

    def init_ui(self):
        main_layout = QVBoxLayout()

        # --- Layout de Entrada de Tareas ---
        input_layout = QHBoxLayout()

        self.id_label = QLabel("ID:")
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("ID (para Actualizar/Eliminar)")
        self.id_input.setEnabled(False)
        self.id_input.setFixedWidth(50)

        self.desc_input = QLineEdit()
        self.desc_input.setPlaceholderText("Descripción de la Tarea")

        self.date_input = QDateEdit(QDate.currentDate())
        self.date_input.setCalendarPopup(True)
        self.date_input.setMinimumDate(QDate.currentDate())

        self.priority_combo = QComboBox()
        self.priority_combo.addItems(["Baja", "Media", "Alta"])

        # NUEVO: ComboBox para el Estado
        self.status_combo = QComboBox()
        self.status_combo.addItems(["Pendiente", "En Desarrollo", "Completada"])

        input_layout.addWidget(self.id_label)
        input_layout.addWidget(self.id_input)
        input_layout.addWidget(QLabel("Descripción:"))
        input_layout.addWidget(self.desc_input)
        input_layout.addWidget(QLabel("Fecha Vencimiento:"))
        input_layout.addWidget(self.date_input)
        input_layout.addWidget(QLabel("Prioridad:"))
        input_layout.addWidget(self.priority_combo)
        input_layout.addWidget(QLabel("Estado:")) # ETIQUETA NUEVA
        input_layout.addWidget(self.status_combo) # COMBOBOX NUEVO

        main_layout.addLayout(input_layout)

        # --- Layout de Botones ---
        button_layout = QHBoxLayout()

        self.add_button = QPushButton("Agregar Tarea")
        self.add_button.clicked.connect(self.add_task)
        self.add_button.setStyleSheet("background-color: #4CAF50; color: white;")

        self.update_button = QPushButton("Actualizar Tarea")
        self.update_button.clicked.connect(self.update_task)
        self.update_button.setStyleSheet("background-color: #008CBA; color: white;")

        self.delete_button = QPushButton("Eliminar Tarea")
        self.delete_button.clicked.connect(self.delete_task)
        self.delete_button.setStyleSheet("background-color: #f44336; color: white;")

        self.clear_button = QPushButton("Limpiar Campos")
        self.clear_button.clicked.connect(self.clear_fields)
        self.clear_button.setStyleSheet("background-color: #555555; color: white;")

        button_layout.addWidget(self.add_button)
        button_layout.addWidget(self.update_button)
        button_layout.addWidget(self.delete_button)
        button_layout.addWidget(self.clear_button)

        main_layout.addLayout(button_layout)

        # --- Tabla de Tareas ---
        self.task_table = QTableWidget()
        self.task_table.setColumnCount(5) # Las 5 columnas siguen siendo ID, Descripción, Fecha, Prioridad, Estado
        self.task_table.setHorizontalHeaderLabels(["ID", "Descripción", "Fecha Vencimiento", "Prioridad", "Estado"])
        self.task_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.task_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.task_table.itemSelectionChanged.connect(self.populate_fields_from_table)

        main_layout.addWidget(self.task_table)

        # --- Mensaje de Estado ---
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: blue; font-weight: bold;")
        main_layout.addWidget(self.status_label)

        self.setLayout(main_layout)

    def load_tasks_to_table(self):
        """Carga todas las tareas del TaskManager y las muestra en la tabla."""
        self.task_table.setRowCount(0)
        tasks = self.task_manager.get_all_tasks()
        self.task_table.setRowCount(len(tasks))
        for row_idx, task in enumerate(tasks):
            self.task_table.setItem(row_idx, 0, QTableWidgetItem(str(task.id)))
            self.task_table.setItem(row_idx, 1, QTableWidgetItem(task.description))
            self.task_table.setItem(row_idx, 2, QTableWidgetItem(task.due_date))
            self.task_table.setItem(row_idx, 3, QTableWidgetItem(task.priority))
            self.task_table.setItem(row_idx, 4, QTableWidgetItem(task.status)) # Aseguramos que el estado se muestre

        self.status_label.setText(f"Tareas cargadas exitosamente. Total: {len(tasks)}")

    def add_task(self):
        description = self.desc_input.text().strip()
        due_date = self.date_input.date().toString("yyyy-MM-dd")
        priority = self.priority_combo.currentText()
        # El estado para nuevas tareas por defecto es "Pendiente" en la clase Task,
        # así que no necesitamos obtenerlo de la UI aquí.

        if not description:
            QMessageBox.warning(self, "Error de Entrada", "La descripción de la tarea no puede estar vacía.")
            return

        try:
            self.task_manager.add_task(description, due_date, priority)
            self.load_tasks_to_table()
            self.clear_fields()
            self.status_label.setText("Tarea agregada exitosamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error al Agregar", f"No se pudo agregar la tarea: {e}")
            self.status_label.setText("Error al agregar tarea.")

    def update_task(self):
        task_id_text = self.id_input.text().strip()
        if not task_id_text:
            QMessageBox.warning(self, "Error de Entrada", "Seleccione una tarea de la tabla para actualizarla.")
            return

        try:
            task_id = int(task_id_text)
        except ValueError:
            QMessageBox.warning(self, "Error de Entrada", "El ID de la tarea debe ser un número entero.")
            return

        description = self.desc_input.text().strip()
        due_date = self.date_input.date().toString("yyyy-MM-dd")
        priority = self.priority_combo.currentText()
        status = self.status_combo.currentText() # NUEVO: Obtenemos el estado del ComboBox

        if not description:
            QMessageBox.warning(self, "Error de Entrada", "La descripción no puede estar vacía.")
            return

        # Pasamos todos los valores actualizados, incluido el estado
        if self.task_manager.update_task(task_id, description, due_date, priority, status): # <-- Pasamos status
            self.load_tasks_to_table()
            self.clear_fields()
            self.status_label.setText(f"Tarea con ID {task_id} actualizada exitosamente.")
        else:
            QMessageBox.warning(self, "Actualización Fallida", f"No se encontró la tarea con ID {task_id}.")
            self.status_label.setText(f"Error: Tarea con ID {task_id} no encontrada.")

    def delete_task(self):
        task_id_text = self.id_input.text().strip()
        if not task_id_text:
            QMessageBox.warning(self, "Error de Entrada", "Seleccione una tarea de la tabla para eliminarla.")
            return

        reply = QMessageBox.question(self, "Confirmar Eliminación",
                                     f"¿Está seguro de que desea eliminar la tarea con ID {task_id_text}?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.No:
            return

        try:
            task_id = int(task_id_text)
        except ValueError:
            QMessageBox.warning(self, "Error de Entrada", "El ID de la tarea debe ser un número entero.")
            return

        if self.task_manager.delete_task(task_id):
            self.load_tasks_to_table()
            self.clear_fields()
            self.status_label.setText(f"Tarea con ID {task_id} eliminada exitosamente.")
        else:
            QMessageBox.warning(self, "Eliminación Fallida", f"No se encontró la tarea con ID {task_id}.")
            self.status_label.setText(f"Error: Tarea con ID {task_id} no encontrada.")

    def populate_fields_from_table(self):
        """Pobla los campos de entrada cuando una fila de la tabla es seleccionada."""
        selected_items = self.task_table.selectedItems()
        if selected_items:
            row = selected_items[0].row()
            task_id = self.task_table.item(row, 0).text()
            description = self.task_table.item(row, 1).text()
            due_date_str = self.task_table.item(row, 2).text()
            priority = self.task_table.item(row, 3).text()
            status = self.task_table.item(row, 4).text() # NUEVO: Obtenemos el estado de la tabla

            self.id_input.setText(task_id)
            self.desc_input.setText(description)
            self.date_input.setDate(QDate.fromString(due_date_str, "yyyy-MM-dd"))
            self.priority_combo.setCurrentText(priority)
            self.status_combo.setCurrentText(status) # NUEVO: Establecemos el estado en el ComboBox
        else:
            self.clear_fields()

    def clear_fields(self):
        """Limpia todos los campos de entrada."""
        self.id_input.clear()
        self.desc_input.clear()
        self.date_input.setDate(QDate.currentDate())
        self.priority_combo.setCurrentIndex(0)
        self.status_combo.setCurrentIndex(0) # NUEVO: Establecemos el estado por defecto a "Pendiente"
        self.status_label.clear()

    def closeEvent(self, event):
        """Sobrescribe el evento de cierre para cerrar el libro de Excel."""
        self.task_manager.close()
        event.accept()

if __name__ == "__main__":
    # Opcional: Eliminar el archivo de Excel de prueba para empezar de cero cada vez.
    # Comenta esta línea si quieres que los datos persistan entre ejecuciones.
    #if os.path.exists("tasks.xlsx"):
    #    os.remove("tasks.xlsx")

    app = QApplication(sys.argv)
    ex = TaskApp()
    ex.show()
    sys.exit(app.exec())