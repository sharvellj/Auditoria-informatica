# mi_manejador_tareas/tests/test_task_manager.py

import pytest
import os
import openpyxl 

# ¡Importante! Ahora se importa desde 'src.task_manager' y 'src.task'
from src.task_manager import TaskManager
from src.task import Task

# Fixture para asegurar un archivo Excel limpio para cada prueba
@pytest.fixture(scope="function")
def clean_task_manager():
    excel_file = "test_tasks.xlsx"
    if os.path.exists(excel_file):
        os.remove(excel_file)
    manager = TaskManager(excel_file=excel_file)
    yield manager
    manager.close()
    if os.path.exists(excel_file):
        os.remove(excel_file)

# --- PRUEBAS UNITARIAS Y DE INTEGRACIÓN PARA TASKMANAGER ---

# Prueba 1: Inicialización y creación de archivo Excel
def test_manager_initialization(clean_task_manager):
    """Verifica que el TaskManager se inicializa y crea el archivo Excel con encabezados."""
    manager = clean_task_manager
    assert os.path.exists(manager.excel_file)
    tasks = manager.get_all_tasks()
    assert len(tasks) == 0

# Prueba 2: Agregar una tarea correctamente
def test_add_single_task(clean_task_manager):
    """Verifica que se puede agregar una única tarea y se guarda correctamente."""
    manager = clean_task_manager
    task = manager.add_task("Comprar leche", "2025-06-05", "Alta")
    assert task.id == 1
    assert task.description == "Comprar leche"
    assert task.status == "Pendiente"

    loaded_tasks = manager.get_all_tasks()
    assert len(loaded_tasks) == 1
    assert loaded_tasks[0].description == "Comprar leche"
    assert loaded_tasks[0].id == 1

# Prueba 3: Agregar múltiples tareas y verificar IDs secuenciales
def test_add_multiple_tasks(clean_task_manager):
    """Verifica que los IDs se autoincrementan correctamente al agregar múltiples tareas."""
    manager = clean_task_manager
    task1 = manager.add_task("Tarea Uno", "2025-06-01", "Baja")
    task2 = manager.add_task("Tarea Dos", "2025-06-02", "Media")
    task3 = manager.add_task("Tarea Tres", "2025-06-03", "Alta")

    assert task1.id == 1
    assert task2.id == 2
    assert task3.id == 3

    loaded_tasks = manager.get_all_tasks()
    assert len(loaded_tasks) == 3
    assert loaded_tasks[0].id == 1
    assert loaded_tasks[1].id == 2
    assert loaded_tasks[2].id == 3

# Prueba 4: Obtener todas las tareas (lectura)
def test_get_all_tasks(clean_task_manager):
    """Verifica que `get_all_tasks` retorna todas las tareas guardadas."""
    manager = clean_task_manager
    manager.add_task("Tarea A", "2025-01-01", "Baja")
    manager.add_task("Tarea B", "2025-01-02", "Media")
    
    tasks = manager.get_all_tasks()
    assert len(tasks) == 2
    assert any(t.description == "Tarea A" for t in tasks)
    assert any(t.description == "Tarea B" for t in tasks)

# Prueba 5: Actualizar una tarea existente (cambio de descripción y estado)
def test_update_existing_task(clean_task_manager):
    """Verifica que se puede actualizar una tarea por su ID."""
    manager = clean_task_manager
    task = manager.add_task("Tarea Original", "2025-06-05", "Media")
    
    updated = manager.update_task(task.id, description="Tarea Actualizada", status="Completada")
    assert updated is True

    loaded_tasks = manager.get_all_tasks()
    updated_task = next((t for t in loaded_tasks if t.id == task.id), None)
    assert updated_task is not None
    assert updated_task.description == "Tarea Actualizada"
    assert updated_task.status == "Completada"
    assert updated_task.priority == "Media"

# Prueba 6: Intentar actualizar una tarea inexistente
def test_update_non_existent_task(clean_task_manager):
    """Verifica que `update_task` retorna False si la tarea no existe."""
    manager = clean_task_manager
    manager.add_task("Tarea 1", "2025-06-01", "Baja")

    updated = manager.update_task(999, description="Tarea Falsa")
    assert updated is False
    
    tasks = manager.get_all_tasks()
    assert len(tasks) == 1
    assert tasks[0].description == "Tarea 1"


# Prueba 7: Eliminar una tarea existente
def test_delete_existing_task(clean_task_manager):
    """Verifica que se puede eliminar una tarea por su ID."""
    manager = clean_task_manager
    task1 = manager.add_task("Tarea a Eliminar", "2025-06-05", "Alta")
    task2 = manager.add_task("Tarea a Mantener", "2025-06-06", "Baja")

    deleted = manager.delete_task(task1.id)
    assert deleted is True

    loaded_tasks = manager.get_all_tasks()
    assert len(loaded_tasks) == 1
    assert loaded_tasks[0].id == task2.id

# Prueba 8: Intentar eliminar una tarea inexistente
def test_delete_non_existent_task(clean_task_manager):
    """Verifica que `delete_task` retorna False si la tarea no existe."""
    manager = clean_task_manager
    manager.add_task("Tarea Unica", "2025-06-01", "Baja")

    deleted = manager.delete_task(999)
    assert deleted is False
    
    tasks = manager.get_all_tasks()
    assert len(tasks) == 1

# Prueba 9: Manejo de archivo Excel vacío o corrupto (se inicializa correctamente)
def test_handle_empty_excel_file(clean_task_manager):
    """Verifica que un archivo Excel vacío o con encabezados incompletos se maneja e inicializa correctamente."""
    excel_file = "test_empty_tasks.xlsx"
    if os.path.exists(excel_file):
        os.remove(excel_file)
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws['A1'] = "BadHeader"
    ws['B1'] = "OtraCosa"
    ws.append([1, "Dato", "Basura"])
    wb.save(excel_file)
    wb.close()

    manager = TaskManager(excel_file=excel_file)
    tasks = manager.get_all_tasks()
    assert len(tasks) == 0
    assert manager.sheet['A1'].value == "ID"

    manager.add_task("Primera Tarea en Archivo Malo", "2025-07-01", "Baja")
    new_tasks = manager.get_all_tasks()
    assert len(new_tasks) == 1
    assert new_tasks[0].description == "Primera Tarea en Archivo Malo"

    manager.close()
    if os.path.exists(excel_file):
        os.remove(excel_file)

# Prueba 10: Persistencia de datos al cerrar y reabrir (Integración completa)
def test_data_persistence_on_close_reopen():
    """Verifica que las tareas persisten en el archivo Excel al cerrar y reabrir el TaskManager."""
    excel_file = "temp_persistence_test.xlsx"
    if os.path.exists(excel_file):
        os.remove(excel_file)

    manager1 = TaskManager(excel_file=excel_file)
    manager1.add_task("Tarea Persistente 1", "2025-06-10", "Alta")
    manager1.add_task("Tarea Persistente 2", "2025-06-11", "Media")
    manager1.close()

    manager2 = TaskManager(excel_file=excel_file)
    tasks_reloaded = manager2.get_all_tasks()
    assert len(tasks_reloaded) == 2
    assert any(t.description == "Tarea Persistente 1" for t in tasks_reloaded)
    assert any(t.description == "Tarea Persistente 2" for t in tasks_reloaded)
    
    manager2.close()
    if os.path.exists(excel_file):
        os.remove(excel_file)